chmod +x ./gradlew
./gradlew test
